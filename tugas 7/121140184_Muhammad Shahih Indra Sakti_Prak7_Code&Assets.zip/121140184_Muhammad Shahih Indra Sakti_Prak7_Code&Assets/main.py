import tkinter as tk
from tkinter import filedialog
from pygame import mixer

class MusicPlayer:
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("Music Player")
        
        self.current_song = None
        self.song_list = []
        self.current_index = 0
        
        self.create_widgets()
        self.create_menu()

    def create_widgets(self):
        self.open_button = tk.Button(self.window, text="Open", command=self.open_file)
        self.open_button.pack(pady=10)

        play_image = tk.PhotoImage(file="play.png")
        self.play_button = tk.Button(self.window, image=play_image, command=self.play_music)
        self.play_button.image = play_image
        self.play_button.pack(pady=5)

        pause_image = tk.PhotoImage(file="pause.png")
        self.pause_button = tk.Button(self.window, image=pause_image, command=self.pause_music)
        self.pause_button.image = pause_image
        self.pause_button.pack(pady=5)

        stop_image = tk.PhotoImage(file="stop.png")
        self.stop_button = tk.Button(self.window, image=stop_image, command=self.stop_music)
        self.stop_button.image = stop_image
        self.stop_button.pack(pady=5)


    def create_menu(self):
        menubar = tk.Menu(self.window)
        self.window.config(menu=menubar)

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Open", command=self.open_file)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.window.quit)
        menubar.add_cascade(label="File", menu=file_menu)

        playback_menu = tk.Menu(menubar, tearoff=0)
        playback_menu.add_command(label="Play", command=self.play_music)
        playback_menu.add_command(label="Pause", command=self.pause_music)
        playback_menu.add_command(label="Stop", command=self.stop_music)
        menubar.add_cascade(label="Playback", menu=playback_menu)

    def open_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("Audio Files", "*.mp3")])
        if file_path:
            self.song_list.append(file_path)
            if self.current_song is None:
                self.current_index = 0
                self.play_music()

    def play_music(self):
        if self.current_song:
            mixer.music.unpause()
        else:
            if self.song_list:
                self.current_song = self.song_list[self.current_index]
                mixer.init()
                mixer.music.load(self.current_song)
                mixer.music.play()

    def pause_music(self):
        mixer.music.pause()

    def stop_music(self):
        mixer.music.stop()
        self.current_song = None

    def run(self):
        self.window.mainloop()

if __name__ == "__main__":
    music_player = MusicPlayer()
    music_player.run()
